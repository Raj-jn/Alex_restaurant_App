import Routing from "./Routing.js";
import React from "react";

function App() {
  return (
    <>
      <Routing />
    </>
  );
}

export default App;
